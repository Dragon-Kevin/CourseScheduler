/*
 * Room.java
 * Room class by Victoria Mitchell - 11/13/2016
 */

package course_scheduler;

/**
 * Class to hold the classroom names and number of seats
 */
class Room {
    
    public String name;
    public int numberOfSeats;
    public boolean[] timeSlot;
    
    public Room(){
        name = "";
        numberOfSeats = -1;
        
        /* There are 16 time slots for each room.
        8 for MW classes and 8 for TR classes.
        timeSlot = true means that slot is available.
        */
        timeSlot = new boolean[16];
        for (int i=0; i<16; i++){ timeSlot[i] = true; }
        
    }
    
    public Room(String name, int numberOfSeats){
        this.name = name;
        this.numberOfSeats = numberOfSeats;
        timeSlot = new boolean[16];
        for (int i=0; i<16; i++){ timeSlot[i] = true; }
    }

}
